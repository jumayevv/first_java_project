create function update_user_count() returns trigger
    language plpgsql
as
$$
        BEGIN
            IF TG_OP = 'INSERT' THEN
                UPDATE groups
                SET user_count = user_count + 1
                WHERE group_id = NEW.group_id;
            ELSIF TG_OP = 'DELETE' THEN
                UPDATE groups
                SET user_count = user_count - 1
                WHERE group_id = OLD.group_id;
            END IF;
            RETURN new;
        END;
    $$;

alter function update_user_count() owner to postgres;

