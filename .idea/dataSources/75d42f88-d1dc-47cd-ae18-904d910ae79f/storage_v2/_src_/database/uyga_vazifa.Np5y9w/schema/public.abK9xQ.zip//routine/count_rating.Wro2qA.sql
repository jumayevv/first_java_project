create function count_rating(target_id integer) returns numeric
    language plpgsql
as
$$
    declare
        avg numeric;
    begin
        select avg(rating) into avg from book_review where book_id=target_id;
    return avg;
    end;
    $$;

alter function count_rating(integer) owner to postgres;

