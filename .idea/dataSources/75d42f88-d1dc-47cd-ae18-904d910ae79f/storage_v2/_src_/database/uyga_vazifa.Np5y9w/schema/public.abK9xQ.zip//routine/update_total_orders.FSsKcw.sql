create function update_total_orders() returns trigger
    language plpgsql
as
$$
        BEGIN
            IF TG_OP = 'INSERT' THEN
                INSERT INTO customer_statistics
                (customer_id, total_orders)
                VALUES
                    (NEW.customer_id, 1);
            ELSIF TG_OP = 'DELETE' THEN
                UPDATE customer_statistics
                SET total_orders = total_orders - 1
                WHERE customer_id = OLD.customer_id;
            END IF;

            RETURN NEW;
        END
    $$;

alter function update_total_orders() owner to postgres;

