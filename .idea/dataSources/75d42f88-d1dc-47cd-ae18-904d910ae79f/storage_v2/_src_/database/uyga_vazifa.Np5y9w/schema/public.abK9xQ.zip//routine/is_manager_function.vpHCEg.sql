create function is_manager_function() returns trigger
    language plpgsql
as
$$
        BEGIN
        if(old.is_manager=true) then
            raise exception 'error,is_manager is true';
        end if;
         return old;
        END;
    $$;

alter function is_manager_function() owner to postgres;

