create procedure update_order_status(IN order_id integer, IN new_status text)
    language plpgsql
as
$$
    declare
        rows int=0;
BEGIN
    update orders set status=new_status where order_number=order_id;
    select count(order_number) into rows from orders where order_number=order_id;
    raise notice '    % rows affected ',rows;
END
$$;

alter procedure update_order_status(integer, text) owner to postgres;

