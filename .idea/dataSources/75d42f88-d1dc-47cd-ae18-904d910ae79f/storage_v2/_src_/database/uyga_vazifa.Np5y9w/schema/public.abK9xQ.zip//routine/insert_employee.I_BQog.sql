create procedure insert_employee(IN employee_name character varying, IN employee_email character varying, IN department_id integer)
    language plpgsql
as
$$
    BEGIN
    INSERT INTO employees (name, email, department_id)
    VALUES (employee_name, employee_email,department_id);
    raise notice '    id:    % ',currval('employees_id_seq');
    END
$$;

alter procedure insert_employee(varchar, varchar, integer) owner to postgres;

