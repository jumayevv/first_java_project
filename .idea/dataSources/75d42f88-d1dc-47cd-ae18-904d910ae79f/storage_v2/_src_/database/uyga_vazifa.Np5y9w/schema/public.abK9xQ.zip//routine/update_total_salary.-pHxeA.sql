create function update_total_salary() returns trigger
    language plpgsql
as
$$
        BEGIN
        new.total_salary=new.salary + new.bonus;
        RETURN new;
        END;
    $$;

alter function update_total_salary() owner to postgres;

