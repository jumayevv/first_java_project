create function log_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO products_audit (product_id,product_name,price_before,price_after,action,modified_at
    )
    VALUES (NEW.product_id,NEW.product_name,OLD.price,NEW.price,
               CASE WHEN TG_OP = 'INSERT' THEN 'INSERT'
                    WHEN TG_OP = 'UPDATE' THEN 'UPDATE'
                    WHEN TG_OP = 'DELETE' THEN 'DELETE' END,
               CURRENT_TIMESTAMP);
    return new;
    END;
    $$;

alter function log_changes() owner to postgres;

