create function prevent_price_updates() returns trigger
    language plpgsql
as
$$
        BEGIN
            IF TG_OP = 'UPDATE' AND NEW.is_locked = TRUE THEN
                RAISE EXCEPTION 'Price cannot be updated for locked products';
            END IF;

            RETURN NEW;
        END;
    $$;

alter function prevent_price_updates() owner to postgres;

