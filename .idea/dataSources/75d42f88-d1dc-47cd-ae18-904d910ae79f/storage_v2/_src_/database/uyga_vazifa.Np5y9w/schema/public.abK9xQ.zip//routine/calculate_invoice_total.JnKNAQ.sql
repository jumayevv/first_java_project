create procedure calculate_invoice_total(IN invoice_id2 integer)
    language plpgsql
as
$$begin
        raise notice 'sum is:  %',(select sum(amount) from invoice_items where invoice_id = invoice_id2 group by invoice_id);
        end
    $$;

alter procedure calculate_invoice_total(integer) owner to postgres;

