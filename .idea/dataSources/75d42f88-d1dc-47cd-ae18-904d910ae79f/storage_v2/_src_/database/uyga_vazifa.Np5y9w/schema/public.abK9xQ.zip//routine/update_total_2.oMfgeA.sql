create function update_total_2() returns trigger
    language plpgsql
as
$$
begin
    new.total_amount = new.quantity * new.price;
    return new;
end;
$$;

alter function update_total_2() owner to postgres;

