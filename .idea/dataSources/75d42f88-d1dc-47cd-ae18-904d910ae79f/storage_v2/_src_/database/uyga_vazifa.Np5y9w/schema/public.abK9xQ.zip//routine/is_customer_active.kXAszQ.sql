create function is_customer_active() returns trigger
    language plpgsql
as
$$
    BEGIN
      IF NOT EXISTS (SELECT * FROM customers where customer_id=new.customer_id_ord and is_active=true) THEN
        RAISE EXCEPTION 'error, customer not aa active !';
      END IF;
      RETURN NEW;
    END;

$$;

alter function is_customer_active() owner to postgres;

