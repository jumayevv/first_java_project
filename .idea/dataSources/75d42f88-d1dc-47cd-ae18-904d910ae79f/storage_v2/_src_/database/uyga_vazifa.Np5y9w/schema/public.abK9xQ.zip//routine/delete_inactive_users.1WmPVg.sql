create procedure delete_inactive_users(IN inactive_days integer)
    language plpgsql
as
$$
DECLARE
    result INT;
    inactive_interval INTERVAL = inactive_days * INTERVAL '1 day';
BEGIN
    SELECT COUNT(*) INTO result
    FROM users
    WHERE last_activity <= current_date - inactive_interval;

    DELETE FROM users
    WHERE last_activity <= current_date - inactive_interval;

    raise notice ' % ',inactive_interval;
    RAISE NOTICE '% rows affected', result;
END
$$;

alter procedure delete_inactive_users(integer) owner to postgres;

