create procedure update_order_status(IN order_id integer, IN new_status text, IN rows integer)
    language plpgsql
as
$$
BEGIN
    update orders set status=new_status where order_number=order_id;
    select count(order_number) into rows from orders where order_number=order_id;
    raise notice '    % rows affected ',count(rows);
END
$$;

alter procedure update_order_status(integer, text, integer) owner to postgres;

