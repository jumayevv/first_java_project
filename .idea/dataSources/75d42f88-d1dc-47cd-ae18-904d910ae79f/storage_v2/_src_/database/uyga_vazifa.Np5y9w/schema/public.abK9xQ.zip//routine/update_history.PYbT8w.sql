create function update_history() returns trigger
    language plpgsql
as
$$
        BEGIN
        INSERT INTO employees_history (
            employee_id,
            first_name,
            last_name,
            department
        )
        VALUES (
                   old.employee_id,
                   old.first_name,
                   old.last_name,
                   old.department
               );
        RETURN NEW;
        END;
$$;

alter function update_history() owner to postgres;

