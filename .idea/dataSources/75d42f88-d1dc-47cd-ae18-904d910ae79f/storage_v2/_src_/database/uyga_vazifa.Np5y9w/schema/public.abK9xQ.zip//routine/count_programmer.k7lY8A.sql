create function count_programmer(customer integer) returns integer
    language plpgsql
as
$$
declare
 count integer;
begin
 select count(order_id) into count from orders where customer_id=customer;
return count;
 end;
 $$;

alter function count_programmer(integer) owner to postgres;

