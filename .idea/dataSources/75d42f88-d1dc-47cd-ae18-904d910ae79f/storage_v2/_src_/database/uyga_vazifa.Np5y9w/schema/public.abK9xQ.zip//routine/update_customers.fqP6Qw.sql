create function update_customers() returns trigger
    language plpgsql
as
$$
        BEGIN
            IF TG_OP = 'INSERT' THEN
            UPDATE customers
            SET total_orders = total_orders + 1,
                total_amount = total_amount + NEW.total_amount
            WHERE customer_id = NEW.customer_id;
            ELSIF TG_OP = 'DELETE' THEN
            UPDATE customers
            SET total_orders = total_orders - 1,
                total_amount = total_amount - OLD.total_amount
            WHERE customer_id = OLD.customer_id;
            END IF;
            RETURN NEW;
        END;
    $$;

alter function update_customers() owner to postgres;

