create procedure calculate_total_price(IN quantity integer, IN unit_price integer)
    language plpgsql
as
$$
    declare
     result int =0;
        begin
        for i in 1..quantity
            loop
            result=result+unit_price;
            end loop;
        raise notice 'sum is: %',result;
        end
    $$;

alter procedure calculate_total_price(integer, integer) owner to postgres;

