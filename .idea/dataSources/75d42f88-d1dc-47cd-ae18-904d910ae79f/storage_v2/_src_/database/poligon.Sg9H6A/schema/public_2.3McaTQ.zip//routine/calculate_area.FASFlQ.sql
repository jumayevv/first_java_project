create function calculate_area(numb double precision) returns integer
    language plpgsql
as
$$
begin
    raise notice 'uchburchakning yuzi';
end;
$$;

alter function calculate_area(double precision) owner to postgres;

