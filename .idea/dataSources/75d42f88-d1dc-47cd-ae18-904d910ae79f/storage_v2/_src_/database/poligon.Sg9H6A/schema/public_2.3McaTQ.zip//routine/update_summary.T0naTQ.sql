create function update_summary() returns trigger
    language plpgsql
as
$$
        begin
            UPDATE order_summary
            SET total_orders = total_orders + 1,
                total_amount = total_amount * NEW.order_amount
            WHERE customer_id = old.customer_id;

            RETURN NEW;
        end;
    $$;

alter function update_summary() owner to postgres;

