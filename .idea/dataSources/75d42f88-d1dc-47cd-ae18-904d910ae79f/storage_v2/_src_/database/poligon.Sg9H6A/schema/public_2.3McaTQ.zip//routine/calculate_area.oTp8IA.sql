create function calculate_area(numb double precision, numb2 double precision) returns integer
    language plpgsql
as
$$
begin
    raise notice 'doirani yuzi';
end;
$$;

alter function calculate_area(double precision, double precision) owner to postgres;

