create view customer_order_details(fullname, order_id, product_name, quantity, unit_price) as
SELECT (customers.first_name::text || ' '::text) || customers.last_name::text AS fullname,
       o.order_id,
       od.product_name,
       od.quantity,
       od.unit_price
FROM public_2.customers
         JOIN public_2.orders o ON customers.customer_id = o.customer_id
         JOIN public_2.order_details od ON o.order_id = od.order_id;

alter table customer_order_details
    owner to postgres;

