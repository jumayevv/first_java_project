create function check_invoice_func() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.updated_date is null THEN
        new.updated_date = current_date;
    END IF;
        return new;
        END;
$$;

alter function check_invoice_func() owner to postgres;

