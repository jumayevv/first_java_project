create function insert_std_log() returns trigger
    language plpgsql
as
$$
    begin
        if (new.std_class < 11) then
            insert into std_log(std_id, description) VALUES(old.id, concat('hozirgi sinifi  ',new.std_class));
        elseif(new.std_class = 11) then
            insert into std_log(std_id, description) VALUES(old.id, ' bitirdi');
            delete from student_mast where id=old.id;
        end if;
        return new;
        end;
    $$;

alter function insert_std_log() owner to postgres;

