create function update_salary_audit() returns trigger
    language plpgsql
as
$$
        BEGIN
            INSERT INTO salary_audit (
                employee_id,
                old_salary,
                new_salary,
                updated_at
            ) VALUES (
                         OLD.id,
                         OLD.salary,
                         NEW.salary,
                         NOW()
                     );
        RETURN NEW;
        END;
$$;

alter function update_salary_audit() owner to postgres;

