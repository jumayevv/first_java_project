create function check_employee() returns trigger
    language plpgsql
as
$$
BEGIN
    insert into salary_audit(employee_id, old_salary, new_salary, updated_at)
    values(1,old.salary,new.salary,current_date);
    return new;
    END
$$;

alter function check_employee() owner to postgres;

