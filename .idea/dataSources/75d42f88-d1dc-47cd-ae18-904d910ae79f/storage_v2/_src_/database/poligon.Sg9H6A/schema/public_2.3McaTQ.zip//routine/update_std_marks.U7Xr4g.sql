create function update_std_marks() returns trigger
    language plpgsql
as
$$
        BEGIN
            new.total = new.sub1+new.sub2+new.sub3+new.sub4+new.sub5;
            return  new;
        END;
$$;

alter function update_std_marks() owner to postgres;

