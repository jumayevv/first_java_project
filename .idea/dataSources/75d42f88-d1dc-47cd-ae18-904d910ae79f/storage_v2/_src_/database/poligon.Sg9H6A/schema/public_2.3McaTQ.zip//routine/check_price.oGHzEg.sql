create function check_price(p_price double precision) returns boolean
    language plpgsql
as
$$
    begin
        IF p_price < 0 THEN
            RETURN FALSE;
        ELSE
            RETURN TRUE;
        END IF;
    end;
    $$;

alter function check_price(double precision) owner to postgres;

