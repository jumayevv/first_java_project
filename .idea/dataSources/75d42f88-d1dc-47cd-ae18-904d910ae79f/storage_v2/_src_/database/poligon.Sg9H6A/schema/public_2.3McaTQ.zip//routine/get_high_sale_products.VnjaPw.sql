create function get_high_sale_products(inner_sale double precision)
    returns TABLE(product_id integer, product_name character varying, sales_quantity integer, unit_price2 double precision)
    language plpgsql
as
$$begin
    return query
        select * from products where unit_price>=inner_sale;
end;
$$;

alter function get_high_sale_products(double precision) owner to postgres;

