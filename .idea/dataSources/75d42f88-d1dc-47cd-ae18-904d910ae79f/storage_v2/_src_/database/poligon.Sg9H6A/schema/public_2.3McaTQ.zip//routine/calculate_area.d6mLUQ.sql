create function calculate_area(numb integer, numb2 integer, numb3 integer) returns integer
    language plpgsql
as
$$
begin
    raise notice 'doirani yuzi';
end;
$$;

alter function calculate_area(integer, integer, integer) owner to postgres;

