create function check_price() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.price > 0 THEN
        RETURN NEW;
    ELSE
        RAISE EXCEPTION 'error';
    END IF;
END;
$$;

alter function check_price() owner to postgres;

