create function calculate_area(numb integer, numb2 integer) returns integer
    language plpgsql
as
$$
    begin
        raise notice '%',numb*numb2;
    end;
    $$;

alter function calculate_area(integer, integer) owner to postgres;

