create function get_books_by_author(inner_author character varying)
    returns TABLE(author2 character varying, title character varying, genre character varying, publication_year integer)
    language plpgsql
as
$$begin
    return query
    select * from books where author = inner_author;
    end;
$$;

alter function get_books_by_author(varchar) owner to postgres;

