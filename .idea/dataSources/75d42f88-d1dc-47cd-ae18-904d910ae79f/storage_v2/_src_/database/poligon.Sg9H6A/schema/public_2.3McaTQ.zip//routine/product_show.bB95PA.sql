create function product_show() returns trigger
    language plpgsql
as
$$
    declare
        row record;
    begin
        select * into row from products;
        raise notice ' % ',row;
        return new;
    end;
    $$;

alter function product_show() owner to postgres;

