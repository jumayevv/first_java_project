create function get_students_by_grade(inner_grade integer)
    returns TABLE(std_id integer, std_name character varying, outher_grade integer)
    language plpgsql
as
$$begin
    return query
    select * from students where grade=inner_grade;
    end;
$$;

alter function get_students_by_grade(integer) owner to postgres;

